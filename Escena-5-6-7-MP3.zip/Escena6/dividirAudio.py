from pydub import AudioSegment

file_name = r"escena6.wav"
sound = AudioSegment.from_wav(file_name)
for i in range(160):
	start_time = (i*3)*1000
	stop_time = ((i*3)+3)*1000

	print("time:", start_time, "~", stop_time)

	print("ms:", start_time, "~", stop_time)

	word = sound[start_time:stop_time]
	# guardar ruta
	save_name = r"part"+ str(i+1) + file_name[-4:]
	print(save_name)

	word.export(save_name, format="wav", tags={'artist': 'jmvc0010', 'album': save_name[:-4]})
