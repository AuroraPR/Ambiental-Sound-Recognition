#El orden se mete manualmente en el diccionario secuencia.
#timbre, categoria 15, numero audios 3.... etc.
secuencia = [("timbre",15,2),("idle",16,17),("puerta",13,2),("idle",16,18),("conversacion",3,27),("idle",16,13),
             ("aspirador",1,29),("idle",16,11),("persiana",12,4),("idle",16,16),("telefono",14,11),
             ("idle",16,10)]
ficheroCSV = "name,target,category"
contador = 1
for i in range(len(secuencia)):
    for j in range(secuencia[i][2]):
        ficheroCSV+='\n"part'+str(contador)+'.mp3",'+str(secuencia[i][1])+',"'+secuencia[i][0]+'"'
        contador = contador+1
#print(ficheroCSV)
with open('escena6_etiquetada.csv', 'w') as f:
    f.write(ficheroCSV)

print("fichero CSV generado exitosamente.")
